const LoginConstant = {
  login: "Login",
  logWith: "Login with ",
  gmail: "Gmail",
  facebook: "Facebook",
  microsoft: "Microsoft",
  forgerPwd: "Forgot Password?",
  donthave: "Don't have an account? ",
  register: "Register here",
  userplaceholder: "Username",
  emailplaceholder: "Email ID",
  passwordplaceholder: "Password",
  or: "OR",
};

export { LoginConstant };
