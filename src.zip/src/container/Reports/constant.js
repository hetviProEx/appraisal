const SummData = [
  {
    sr: 1,
    kra: "KRA Type 1",
    score1: 1.8,
    score2: 1.79,
    finalScore: 1.79,
  },
  {
    sr: 2,
    kra: "KRA Type 2",
    score1: 1.8,
    score2: 1.79,
    finalScore: 1.79,
  },
];
const Data = [
  {
    sr: 1,
    kra: "Team Retention till GM Level + Team Engagement",
    kpi: "",
    wt: "45%",
    score: 3,
    scoreEarned: 1.35,
    doc: true,
  },
  {
    sr: 1,
    kra: "Market Based Innovation",
    kpi: "",
    wt: "45%",
    score: 5,
    scoreEarned: 2.25,
    doc: false,
  },
  // {
  //   sr: "",
  //   kra: "",
  //   kpi: "",
  //   wt: "",
  //   score: "",
  //   scoreEarned: 1.8,
  //   doc: "",
  // },
];
const Data1 = [
  {
    sr: 1,
    kra: "Expansion",
    kpi: "",
    wt: "70%",
    score: 3,
    scoreEarned: 2.09,
    doc: true,
  },
  {
    sr: 1,
    kra: "Safety & Security",
    kpi: "",
    wt: "30%",
    score: 5,
    scoreEarned: 1.5,
    doc: false,
  },
  // {
  //   sr: "",
  //   kra: "",
  //   kpi: "",
  //   wt: "",
  //   score: "",
  //   scoreEarned: 1.79,
  //   doc: "",
  // },
];

const basicData = ["Parth", "Ram"];
const basicData2 = ["Emplopyee 1", "Emplopyee 2"];
export { SummData, Data, basicData, basicData2, Data1 };
