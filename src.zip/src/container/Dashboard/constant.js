const EmpConst = [
  { txt: "Employee", link: "/employee" },
  { txt: "Basic Profile", link: "/basic-profile" },
  { txt: "Master", link: "/master" },
  { txt: "KRA-Goal,KPI,Weightage", link: "/kra" },
  { txt: "Report", link: "/report" },
];

export { EmpConst };
