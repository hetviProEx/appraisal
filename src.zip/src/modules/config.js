export const configVar = {
  BASE_URL: "https://naapbooks.com",
};

export const apiConstant = {
  // AUTH_LOGIN: "/api/Chat/Login/",
  // AUTH_REGISTER: "/api/Chat/Registration",
  // FORGET_PASSWORD: "/api/Chat/ForgotPassword/",
  // CHANGE_PASSWORD: "/api/Chat/ChangePassword",
  // AUTH_LOGOUT: "/api​/Chat​/Logout​/",
  // CHECK_SESSION: "/api/User/CheckSession/",
  // GET_ALL_USER: "/api/User/GetAllUsers",
};
