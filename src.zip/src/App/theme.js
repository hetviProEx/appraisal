const Theme = {
  mainColor: "#141B5A",
  baseColor: "#B2B2B2",
 };

export { Theme };
