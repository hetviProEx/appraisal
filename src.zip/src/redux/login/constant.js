export const SET_AUTH = "SET_AUTH";

export const LOGIN_INITIATED = "LOGIN_INITIATED";
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGIN_ERROR = "LOGIN_ERROR";

export const LOGOUT = "LOGOUT";
export const LOGOUT_ERROR = "LOGOUT_ERROR";
export const LOGOUT_INITIATED = "LOGOUT_INITIATED";
