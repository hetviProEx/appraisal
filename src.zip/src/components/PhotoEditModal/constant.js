const PhotoConstant = {
  yes: "Yes",
  danger: "danger",
  no: "No",
  header: "Delete photo",
  deleteMessage: "Are you sure you want to remove profile photo?",
};
export { PhotoConstant };
