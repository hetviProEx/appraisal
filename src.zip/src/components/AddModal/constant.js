const AddModConst = {
    st: "*",
    new: "New ",
    desg: "Designation",
    dept: "Department",
    comp: "Company",
    kraType: "KRA Type",
    prd: "Period",
    crtNew: "Create New",
}


export { AddModConst };