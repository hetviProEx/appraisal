import arrowDown from "assets/image/arrow-down.svg";
import eye from "assets/image/eye.svg";
import edit from "assets/image/edit.png";
import editPen from "assets/image/editPen.svg";
import fillClose from "assets/image/fillClose.svg";

export {arrowDown,eye,edit,editPen,fillClose};
